package com.company;

import java.util.Scanner;
import java.util.ArrayList;
import java.io.File;
import java.io.FileNotFoundException;

// create Node
class Node{
    char data;
    ArrayList<Character> arrList;

    // This is the constructor
    public Node(char data){
        this.data = data;
        this.arrList = new ArrayList<Character>();
    }
}

// create directed edge/ follow
class Follows{

    //To get the index of a given node/person in the adjList
    public static int getIndex(char person, ArrayList<Node> adjList){
        int ind = -1; //-1 indicates invalid node/person
        for(int i=0; i<adjList.size(); i++){
            if(adjList.get(i).data == person){
                ind  = i;
                break;
            }
        }
        //returns index number of person/node in the adjList
        return ind;
    }

    //DFS
    public static void DFSUtil(char person, ArrayList<Node> adjList, int[] visited){
        int ind = getIndex(person, adjList);

        if(visited[ind] == 0)
            visited[ind] = 1; // 1 indicates visited or present on the path, which means it an indirect connection
        for(Character ch : adjList.get(ind).arrList){
            DFSUtil(ch, adjList, visited);
        }
    }


    public static String DFS(int ind, ArrayList<Character> arrList, ArrayList<Node> adjList){
        int[] visited = new int[adjList.size()]; // By default all Zero's are assigned initially
        visited[ind] = -1; //  -1 Indicates direct connection

        //  Call the DFSUtil method from all direct connected nodes/persons to find indirectly connected nodes/persons
        for(Character ch : arrList){
            int indx = getIndex(ch, adjList);
            visited[indx] = -1; //  -1 Indicates direct connection
            DFSUtil(ch, adjList, visited);
        }

        String list = ""; // store indirectly connected nodes.persons list as string
        for(int i=0; i<visited.length; i++){
            if(visited[i] == 1)
                list = list + adjList.get(i).data + ", ";
        }

        // To remove the unwanted comma
        if(list.length() > 0){
            list = list.substring(0, list.length()-2);
        }

        return list; // Returns list of indirectly connected nodes/persons as string

    }

    public static void allFollows(char person, ArrayList<Node> adjList){
        int ind = getIndex(person, adjList);
        if(ind == -1){
            return;
        }

// direct followers

        String list = ""; // Store the directly connected nodes.persons list as string
        // Adding all directly connected nodes/persons to list
        for(Character ch : adjList.get(ind).arrList){
            list = list+ch+", ";
        }
        // To remove the unwanted comma(,) at the end of list
        if(list.length() > 0){
            list = list.substring(0, list.length()-2);
        }
        // Displaying all directly connected nodes/persons to list
        System.out.print(person+" directly follows {"+list+"}\n");


// indirect followers

        //call DFS method which returns the indirectly connected nodes/persons list as a string*/
        list = DFS(ind, adjList.get(ind).arrList, adjList);
        /* Displaying all indirectly connected nodes/persons to list */
        System.out.print(person+" indirectly follows {"+list+"}\n");

    }

    public static void main(String[] args) throws FileNotFoundException {

        // Creating an ArrayList of type Node with name adjList
        ArrayList<Node> adjList = new ArrayList<Node>();

        // Reading the input file
        File file = new File("src/com/company/follows_input.txt");
        Scanner sc = new Scanner(file);


        // Reading the data present in input file line by line
        int ind = 0;
        while(sc.hasNextLine()){
            String s = sc.nextLine();

            String[] stringarray = s.split(", ");

            // Adding node to adjList using first character in each line of input
            adjList.add(new Node(stringarray[0].charAt(0)));
            for(int i=0; i< stringarray.length; i++)
            {    if(i==0)
                continue;
                //  Adding nodes to arrList that are having direct edge with each node in adjList*/
                adjList.get(ind).arrList.add(stringarray[i].charAt(0));
            }
            ind++;

        }

        // Testing allFollows()
        allFollows('A', adjList);
        System.out.println();
        allFollows('B', adjList);
        System.out.println();
        allFollows('C', adjList);
        System.out.println();
        allFollows('D', adjList);
        System.out.println();
        allFollows('E', adjList);
        System.out.println();
        allFollows('F', adjList);
        System.out.println();
        allFollows('G', adjList);
        System.out.println();
        allFollows('H', adjList);
        System.out.println();


    }
}