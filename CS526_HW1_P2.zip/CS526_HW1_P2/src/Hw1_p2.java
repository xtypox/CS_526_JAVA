import java.io.IOException;
import java.io.File;
import java.util.Scanner;

public class Hw1_p2 {
	//get Car objects as array and make as parameters
	public static void findByMake(Car[] cars, String make) {
		// for loop to read cars
		int flag=0;
		for (int i = 0; i < cars.length; i++) {
			// compares and ignore case
			if (cars[i].make.equalsIgnoreCase(make)) {
				//print cars by make
				System.out.println(cars[i]);
				flag += 1;
			}
		}
		if (flag==0)
			System.out.println("Cannot locate car make "+make);

	}

	//get Car objects as array and year as parameters
	public static void newerThan(Car[] cars, int year) {
		// for loop to get years of each car line
		int flag=0;
		for (int i = 0; i < cars.length; i++) {
			if (cars[i].year > year) {
				//print if car year is larger
				System.out.println(cars[i]);
				//if (cars[i].year !> year)
				flag += 1;
			}
		}
		if (flag==0)
			System.out.println("Cannot locate cars made later than " +year);
	}

	public static int getFileLineCount(File file) throws IOException
	{

		Scanner count = new Scanner(file);
		int n = 0;
		while ((count.hasNextLine())) {
			n++;
			count.nextLine();
		}


		return n;
	}
	
	public static void main(String[] args) throws IOException {
		File file = new File("src/car_input.txt");
		Scanner in = new Scanner(file); //Scanner class to read file


		//  create an array of Car objects, cars, of size 10
		Car[] cars = new Car[getFileLineCount(file)];
		String n;
		int price, year;



		int i = 0;
		String line;

		while(in.hasNextLine()){
			line = in.nextLine();
			String[] arr = line.split(", ");
			n = arr[0];
			price = Integer.parseInt(arr[1]); //Converting String to int
			year = Integer.parseInt(arr[2]); //Converting String to int
			cars[i] = new Car(n, price, year);
			i++;
		}


		System.out.println("\nAll cars:");
		for (i = 0; i<cars.length; i++) {
			System.out.println(cars[i]);
		}

		String make = "Honda";
		year = 2017;

		System.out.println("\nAll cars made by " + make);
		findByMake(cars, make);
		System.out.println("\nAll cars made after " + year);
		newerThan(cars, year);
		
	}

}
