package com.evahuang;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Random;



class Hw4_p6 {
    public static void main(String args[]){

        HashMap<Integer,String> myMap = new HashMap<>();
        ArrayList<Integer> myArrayList = new ArrayList<>();
        LinkedList<Integer> myLinkedList = new LinkedList<>();
        long startTime,endTime,elapsedTime;

        Random random = new Random(System.currentTimeMillis());

        int keys[] = new int[100000];
        for(int i=0;i<keys.length;i++){
            keys[i] = random.nextInt(1000000) + 1;
        }

        System.out.println("Number of Keys : " + keys.length);
        startTime = System.currentTimeMillis();
        for(int i=0;i<keys.length;i++){
            myMap.put(keys[i],"1");
        }
        endTime = System.currentTimeMillis();
        elapsedTime = endTime-startTime;
        System.out.println("Hashmap average total insert time : " + elapsedTime);

        startTime = System.currentTimeMillis();
        for(int i=0;i<keys.length;i++){
            myArrayList.add(keys[i]);
        }
        endTime = System.currentTimeMillis();
        elapsedTime = endTime-startTime;
        System.out.println("Arraylist average total insert time : " + elapsedTime);

        startTime = System.currentTimeMillis();
        for(int i=0;i<keys.length;i++){
            myLinkedList.add(keys[i]);
        }
        endTime = System.currentTimeMillis();
        elapsedTime = endTime-startTime;
        System.out.println("LinkedList average total insert time : " + elapsedTime);

        random.setSeed(System.currentTimeMillis());

        for(int i = 0 ; i < 100000 ; i++){
            keys[i] = random.nextInt(2_000_000) + 1;//range 1-2000000
        }

        startTime = System.currentTimeMillis();
        for(int i=0;i<keys.length;i++){
            myMap.containsKey(keys[i]);
        }
        endTime = System.currentTimeMillis();
        elapsedTime = endTime-startTime;
        System.out.println("Hashmap average total search time : " + elapsedTime);

        startTime = System.currentTimeMillis();
        for(int i=0;i<keys.length;i++){
            myArrayList.contains(keys[i]);
        }
        endTime = System.currentTimeMillis();
        elapsedTime = endTime-startTime;
        System.out.println("Arraylist average total search time : " + elapsedTime);

        startTime = System.currentTimeMillis();
        for(int i=0;i<keys.length;i++){
            myLinkedList.contains(keys[i]);
        }
        endTime = System.currentTimeMillis();
        elapsedTime = endTime-startTime;
        System.out.println("LinkedList average total search time : " + elapsedTime);
    }
}
/*
class InsertSearchTimeComparison {

    public static void main(String args[]){

        HashMap<Integer,String> myMap = new HashMap<>();
        ArrayList<Integer> myArrayList = new ArrayList<>();
        LinkedList<Integer> myLinkedList = new LinkedList<>();
        long startTime,endTime,elapsedTime;

        Random random = new Random(1000000);

        int keys[] = new int[100000];
        for(int i=0;i<keys.length;i++){
            keys[i] = random.nextInt(1000000) + 1;
        }

        System.out.println("Number of Keys : " + keys.length);
        startTime = System.currentTimeMillis();
        for(int i=0;i<keys.length;i++){
            myMap.put(keys[i],"1");
        }
        endTime = System.currentTimeMillis();
        elapsedTime = endTime-startTime;
        System.out.println("Hashmap average total insert time : " + elapsedTime);

        startTime = System.currentTimeMillis();
        for(int i=0;i<keys.length;i++){
            myArrayList.add(keys[i]);
        }
        endTime = System.currentTimeMillis();
        elapsedTime = endTime-startTime;
        System.out.println("Arraylist average total insert time : " + elapsedTime);

        startTime = System.currentTimeMillis();
        for(int i=0;i<keys.length;i++){
            myLinkedList.add(keys[i]);
        }
        endTime = System.currentTimeMillis();
        elapsedTime = endTime-startTime;
        System.out.println("LinkedList average total insert time : " + elapsedTime);

        random.setSeed(2000000);

        for(int i = 0 ; i < 100000 ; i++){
            keys[i] = random.nextInt(2000000) + 1;
        }

        startTime = System.currentTimeMillis();
        for(int i=0;i<keys.length;i++){
            myMap.containsKey(keys[i]);
        }
        endTime = System.currentTimeMillis();
        elapsedTime = endTime-startTime;
        System.out.println("Hashmap average total search time : " + elapsedTime);

        startTime = System.currentTimeMillis();
        for(int i=0;i<keys.length;i++){
            myArrayList.contains(keys[i]);
        }
        endTime = System.currentTimeMillis();
        elapsedTime = endTime-startTime;
        System.out.println("Arraylist average total search time : " + elapsedTime);

        startTime = System.currentTimeMillis();
        for(int i=0;i<keys.length;i++){
            myLinkedList.contains(keys[i]);
        }
        endTime = System.currentTimeMillis();
        elapsedTime = endTime-startTime;
        System.out.println("LinkedList average total search time : " + elapsedTime);
    }

}*/
